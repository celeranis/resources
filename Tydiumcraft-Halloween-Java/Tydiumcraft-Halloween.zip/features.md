# 1.0 Changelog

## Changed Allays to Ghosts
## Changed Vindicators to Frankestein
## Changed The UI
## Added new grass blockstates
## Changed Leaf Color
## Added Leaves to the ground
## Added Spiderwebs to Trees