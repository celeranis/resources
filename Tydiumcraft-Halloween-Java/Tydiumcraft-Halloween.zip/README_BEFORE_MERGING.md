# Two Options

## 1. Let Bret merge this with the main pack.

## 2. Understand that there are files within this pack that will override the main pack. So DO NOT EVER merge this with the main pack and then push it to the github. Make a new folder named "Halloween-Main-Merge" and merge them both. You will need to fix a few of the things from font.json aswell.